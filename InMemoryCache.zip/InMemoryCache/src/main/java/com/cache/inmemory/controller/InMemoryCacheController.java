package com.cache.inmemory.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cache.inmemory.model.Doctor;


@RestController
@RequestMapping("/hospital/doctor")
@CacheConfig(cacheNames="Doctor")
public class InMemoryCacheController {

	private static final String MONGODB_COLLECTION_NAME = "Doctor";
	@Autowired
	private MongoTemplate mongoTemplate;

	/**
	 * @param doctor
	 * @return
	 */
	@RequestMapping(value="/set",method=RequestMethod.POST)
	public Doctor set(@RequestBody Doctor doctor){
		mongoTemplate.insert(doctor, MONGODB_COLLECTION_NAME);
		return doctor;
	}
	/**
	 * @param doctor
	 * @return
	 */
	@RequestMapping(value="/update",method=RequestMethod.POST)
	@CachePut(keyGenerator="keyGenerator")
	public Doctor update(@RequestBody Doctor doctor){
		mongoTemplate.save(doctor, MONGODB_COLLECTION_NAME);
		return doctor;
	}
	/**
	 * @param Id
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value="/get/{Id}",method=RequestMethod.GET)
	@Cacheable(keyGenerator="keyGenerator")
	public Doctor get(@PathVariable Integer Id) throws IOException {
		System.out.println("method /get/{doctorId} from mongodb executed "+Id);
		return mongoTemplate.findById(Id,Doctor.class, MONGODB_COLLECTION_NAME);
	}

	/**
	 * @param key
	 * @return
	 */
	@RequestMapping(value="/del/{key}",method=RequestMethod.DELETE)
	@CacheEvict(keyGenerator="keyGenerator")
	public String delKey(@PathVariable String key) {
		System.out.println("method /del/{key} executed"+key);
		Query q=new Query();
		q.addCriteria(Criteria.where("keyname").is(key));
		mongoTemplate.findAndRemove(q,Doctor.class, MONGODB_COLLECTION_NAME);
		return "deleted key:"+key;
	}

	/**
	 * @param e
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public String invalidRequest(Exception e) {
		return "invalid request";
	}


}
