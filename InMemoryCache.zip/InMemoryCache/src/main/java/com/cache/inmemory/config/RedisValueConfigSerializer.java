package com.cache.inmemory.config;

import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.stereotype.Component;
/**
 * @author amlanmohanty
 *
 */
@Component
public class RedisValueConfigSerializer implements RedisSerializer<Object> {

	@Override
	public Object deserialize(byte[] bytes)  {
		return  org.springframework.util.SerializationUtils.deserialize(bytes);
	}

	@Override
	public byte[] serialize(Object t) {
		return org.springframework.util.SerializationUtils.serialize(t);
	}



}
